# Automated AMI and Snapshot Deletion
#
# This function will search for all images having a tag with "DeleteOn". 
# Upon creating the array of tagged images, we check that the DeleteOn tag value
# is matching current date, then deregister them and remove all the
# snapshots associated with that AMI.

import boto3
import collections
import datetime
import time
import sys

def lambda_handler(event, context):

    # Define DynamoDB resources and tables
    dynamodb = boto3.resource('dynamodb','us-east-1')
    dynamodb_east2 = boto3.resource('dynamodb','us-east-2')
    table = dynamodb.Table('AMI-Source')
    table_east2 = dynamodb_east2.Table('AMI-Target')

    # Define regions list
    regions = ['us-east-1','us-east-2']
    
    for region in regions:
        reg=region
        #EC2 connection beginning
        ec2con = boto3.client('ec2',region_name=reg)
        ec2images = boto3.resource('ec2',region_name=reg)
        images = ec2images.images.filter(Owners=["self"])
        
        imagesList = []

        # Loop through each image
        for image in images:
            try:
                if image.tags is not None:
                    deletion_date = [
                        t.get('Value') for t in image.tags
                        if t['Key'] == 'DeleteOn'][0]
                    delete_date = time.strptime(deletion_date, "%m-%d-%Y")
            except IndexError:
                deletion_date = False
                delete_date = False
                amiNameTag = False

            today_time = datetime.datetime.now().strftime('%m-%d-%Y')
            today_date = time.strptime(today_time, '%m-%d-%Y')

            # If image's DeleteOn date is less than or equal to today,
            # add this image to our list of images to process later
            if delete_date == today_date:
                imagesList.append(image.id)

        print "About to process the following AMIs:"
        print imagesList

        myAccount = boto3.client('sts').get_caller_identity()['Account']
        snapshots = ec2con.describe_snapshots(MaxResults=1000, OwnerIds=[myAccount])['Snapshots']

        # loop through list of image IDs
        for image in imagesList:
            print "deregistering image %s" % image
            amiResponse = ec2con.deregister_image(
                DryRun=False,
                ImageId=image,
            )

            for snapshot in snapshots:
                if snapshot['Description'].find(image) > 0:
                    snap = ec2con.delete_snapshot(SnapshotId=snapshot['SnapshotId'])
                    print "Deleting snapshot " + snapshot['SnapshotId']
                    print "-------------"