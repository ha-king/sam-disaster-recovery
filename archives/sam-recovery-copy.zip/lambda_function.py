import boto3
import collections
import datetime
import sys
import pprint

ec = boto3.client('ec2', region_name='us-east-1')
ec_copy = boto3.client('ec2', region_name='us-east-2')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
dynamodb_east2 = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('AMI-Source')
table_east2 = dynamodb_east2.Table('AMI-Target')
name = []
ami_ids = []
        
def lambda_handler(event, context):
    
    reservations = ec.describe_instances(
        Filters=[
            {'Name': 'tag:Backup', 'Values': ['Yes']}
        ]
    ).get(
        'Reservations', []
    )

    instances = sum(
        [
            [i for i in r['Instances']]
            for r in reservations
        ], [])
    
    # CreateTime formatted timestamp for tagging  
    create_time = datetime.datetime.now()
    create_fmt = create_time.strftime('%m-%d-%Y')
    create_fmt = str(create_fmt)
    
    # DeleteTime formatted timestamp for tagging
    retention_days = 7
    delete_date = datetime.date.today() + datetime.timedelta(days=retention_days)
    delete_fmt = delete_date.strftime('%m-%d-%Y')
    
    for instance in instances:
        for tag in instance['Tags']:
            if 'Name' in tag['Key']:
                name = tag['Value']
                print (tag['Value'])

        response = table.get_item(
            Key={
                'ami_name': name,
                'date': create_fmt
            }
        )
        item = response['Item']
        print(item)
        
        
        AMIid = ec_copy.copy_image(
            SourceRegion='us-east-1', 
            SourceImageId=response['Item']['ami_id'], 
            Name=response['Item']['ami_name']+' - '+create_fmt+' - Recovery'
        )
        print (AMIid['ImageId'])
        
        ami_id = str(AMIid['ImageId'])
        
        response_east2 = table_east2.put_item(
            Item={
                'ami_name': name,
                'date': create_fmt,
                'ami_id': ami_id
            }
        )
        
        ec_copy.create_tags(
            Resources=[ami_id], 
            Tags=[
                {'Key': 'Name', 'Value': name},
                {'Key': 'DeleteOn', 'Value': delete_fmt}
            ]
        )
        