import boto3
import collections
import datetime
import sys
import pprint

ec = boto3.client('ec2', region_name='us-east-1')
ec_target = boto3.client('ec2', region_name='us-east-2')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('U360-AMI-Source')
name = []
ami_ids = []

def lambda_handler(event, context):
    
    reservations = ec.describe_instances(
        Filters=[
            {'Name': 'tag:Backup', 'Values': ['XXX']},
            {'Name': 'tag:Environment', 'Values': ['Dev']}
        ]
    ).get(
        'Reservations', []
    )

    instances = sum(
        [
            [i for i in r['Instances']]
            for r in reservations
        ], [])

    print "Found %d instances that need backing up" % len(instances)

    to_tag = collections.defaultdict(list)

    for index, instance in enumerate(instances):
        try:
            retention_days = [
                int(t.get('Value')) for t in instance['Tags']
                if t['Key'] == 'Retention'][0]
        except IndexError:
            retention_days = 7

        for tag in instance['Tags']:
            if 'Name' in tag['Key']:
                name.append(tag['Value'])

        print (name[index])
                
        create_time = datetime.datetime.now()
        create_fmt = create_time.strftime('%m-%d-%Y')
        
        AMIid = ec.create_image(
            InstanceId=instance['InstanceId'], 
            Name=name[index] + " - " + create_fmt + " - Recovery AMI", 
            Description="Recovery created AMI of instance " + name[index] + " on " + create_fmt, 
            NoReboot=True, 
            DryRun=False
        )
            
        to_tag[retention_days].append(AMIid['ImageId'])
        ami_ids.append(AMIid['ImageId'])
            
        print "Retaining AMI %s of instance %s for %d days" % (
            AMIid['ImageId'],
            instance['InstanceId'],
            retention_days,
        )

    print (to_tag)
    print (ami_ids)
    print (name)
    
    for x, y in zip(ami_ids, name):
        print y
        ec.create_tags(
            Resources=[x],
            Tags=[
                {'Key': 'Name', 'Value': y+' - '+create_fmt+' - Recovery'}
            ]
        )
        response = table.put_item(
            Item={
                'ami_name': y,
                'date': create_fmt,
                'ami_id': x
            }
        )
        
    for retention_days in to_tag.keys():
        delete_date = datetime.date.today() + datetime.timedelta(days=retention_days)
        delete_fmt = delete_date.strftime('%m-%d-%Y')
        print "%d AMIs expire on %s" % (len(to_tag[retention_days]), delete_fmt)
    
        ec.create_tags(
            Resources=to_tag[retention_days],
            Tags=[
                {'Key': 'DeleteOn', 'Value': delete_fmt}
            ]
        )
            